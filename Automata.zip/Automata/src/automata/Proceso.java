/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automata;

/**
 *
 * @author luisf
 */
public class Proceso {
      int a,i=0,j=0; int aceptamos=0;
                          //A,B,C,#
                          //0,1,2,3                           
        int [][] matriz = {{0,1,0,-1},//0
                           {0,2,0,-1},//1
                           {3,3,3,-1},//2
                           {3,3,3,999}};//3
                          
     String cadena="";
       
//-------------------------Convertir cadena original a cadena con numeros------------------------------------------------------       
       /* for (int x = 0; x < cadena.length(); x++) {
           if (cadena.charAt(x)=='a') {
                i=0;
            }
            else if(cadena.charAt(x)=='b'){
               i=1;
            }else if(cadena.charAt(x)=='c'){
                i=2;
            }else if(cadena.charAt(x)=='#'){
             i=3;    
            }
//-------------------------Procedimientos feos------------------------------------------------------           
           aceptamos=matriz[j][i];
            System.out.println("i= "+i+" j= "+j+" aceptamos= "+aceptamos);
           if (x==cadena.length()-1) {
                if (aceptamos==-1) {
                  System.out.println("Cadena fea");  
                }
                else{
                System.out.println("Cadena bonita");    
                }//else de aceptacion   
            }else {
               j=aceptamos; 
               System.out.println("nuevo j="+j);
               
           }//else de longitud y aceptacion
            
        }//for      */ 
}
